import SwiftUI

struct StepView: View {
    
    var screentSize : CGSize
    
    @Binding var currentMode: GameMode
    
    var body: some View {
        VStack {  
            SwitchView(
                screentSize: screentSize,
                count: steps.count,
                indexButtonType: "dot",
                showProgress: false,
                currentMode: $currentMode
            ) {
                Button  {
                } label: {
                    Image("snowflake")
                        .resizable()
                        .renderingMode(.template)
                        .foregroundColor(Colors.Blue)
                        .frame(width: 30, height: 30)
                    
                    Text("Snowflake Paper Cutting Process")
                        .foregroundColor(.black)
                        .font(.subheadline.bold())
                    
                    Spacer()
                    
                    Button {
                        currentMode = .inIntro
                    } label: {
                        Image(systemName: "house.fill").foregroundColor(.white)
                    }
                    .font(.title3)
                    .foregroundColor(.white)
                    .padding(8)
                    .background(Colors.Blue, in: Circle())
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            } mainContent: {
                
                ForEach(steps) { step in
                    VStack {
                        Image(step.image)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: screentSize.height / 3)
                        
                        VStack(alignment: .leading, spacing: 20) {
                            Text(step.title)
                                .font(.largeTitle.bold())
                                .foregroundColor(.black)
                            
                            Text(step.description)
                                .font(.title3)
                                .foregroundColor(.black)
                        }
                        .padding(.top, 60)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                    .padding()
                    .frame(width: screentSize.width)
                }
                
            } footContent: {
                EmptyView()
            }
            .frame(width: screentSize.width, height: screentSize.height)
        }
        .background(Colors.Background)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
    }
}

struct Step_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

