import SwiftUI

struct IntroView: View {
    
    var screentSize : CGSize
    
    @Binding var currentMode: GameMode
    
    var body: some View {
        VStack {
            Image("header")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: screentSize.width)
                .ignoresSafeArea()
            
            Image("title")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .padding()
            
            
            Text("Learn Chinese paper cutting basics in a quick tutorial, then dive into the world of symmetrical art challenges.")
                .foregroundColor(.black)
                .padding(.horizontal, 20)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.bottom, 40)
            
            
            Spacer()
            
            
            Button("Start Tutorial") {
                currentMode = .inStep
            }
            .frame(width: screentSize.width - 80)
            .font(.title3.bold())
            .foregroundColor(.white)
            .padding(15)
            .background(
                Colors.Yellow,
                in: RoundedRectangle(cornerRadius: 15)
            )
            .shadow(color: Color.gray.opacity(0.5), radius: 5, x: 0, y: 2)
            .onTapGesture {
                currentMode = .inStep
            }
            
            
            Button("Start Game") {
                currentMode = .inGame
            }
            .frame(width: screentSize.width - 80)
            .font(.title3.bold())
            .foregroundColor(.white)
            .padding(15)
            .background(
                Colors.Green,
                in: RoundedRectangle(cornerRadius: 15)
            )
            .shadow(color: Color.gray.opacity(0.5), radius: 5, x: 0, y: 2)
            .padding()
            .onTapGesture {
                currentMode = .inGame
            }
            
            
            Spacer()
        }
        .background(Colors.Background)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        
        .ignoresSafeArea()
    }
}

struct Intro_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

