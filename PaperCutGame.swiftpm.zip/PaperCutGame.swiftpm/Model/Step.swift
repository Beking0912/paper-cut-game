import SwiftUI

struct Step: Identifiable {
    var id = UUID().uuidString
    var image: String
    var title: String
    var description: String
    var color: Color
}

var steps : [Step] = [
    Step(image: "intro.step1", title: "Step 1", description: "Fold a square piece of paper along the diagonal.",color: Colors.Blue),
    Step(image: "intro.step2", title: "Step 2", description: "Fold it again.",color: Colors.Yellow),
    Step(image: "intro.step3", title: "Step 3", description: "Fold it into thirds.",color: Colors.Red),
    Step(image: "intro.step4", title: "Step 4", description: "Fold it at another corner.",color: Colors.Green),
    Step(image: "intro.step5", title: "Step 5", description: "Draw the desired pattern on the paper.",color: Colors.Blue),
    Step(image: "intro.step6", title: "Step 6", description: "Cut along the traced lines with scissors.",color: Colors.Yellow),
    Step(image: "intro.step7", title: "Step 7", description: "Unfold the paper, revealing a symmetrical design.",color: Colors.Red),
    Step(image: "startgame", title: "Unveiling Symmetry", description: "Can you predict the symmetrical design unfolding from our folded creations?",color: Colors.Green)
]

